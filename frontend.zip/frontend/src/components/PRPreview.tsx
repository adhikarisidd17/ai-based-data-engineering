import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { Spinner } from '@/components/ui/spinner';
import axios from 'axios';

export default function PRPreview({ requestId }) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [prData, setPrData] = useState(null);
  const [error, setError] = useState(null);

  // Fetch preview once PR is generated in the backend
  useEffect(() => {
    if (open) {
      fetchPRPreview();
    }
  }, [open]);

  const fetchPRPreview = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await axios.get(`/api/preview-pr/${requestId}`);
      setPrData(res.data);
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Preview PR</Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <Card>
          <CardHeader>
            <h3>Pull Request Preview</h3>
          </CardHeader>
          <CardContent>
            {loading && <Spinner />}
            {error && <p className="text-red-500">Failed to load preview.</p>}
            {prData && (
              <>
                <h4 className="text-xl font-semibold">{prData.title}</h4>
                <p className="mt-2 whitespace-pre-wrap">{prData.body}</p>
                <div className="mt-4">
                  <h5 className="font-medium">Changes:</h5>
                  <pre className="bg-gray-100 p-4 rounded overflow-auto text-sm">
                    {prData.diff}
                  </pre>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
}
